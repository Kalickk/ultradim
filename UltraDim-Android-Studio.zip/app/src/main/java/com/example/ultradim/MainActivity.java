package com.example.ultradim;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.graphics.Color;

public class MainActivity extends Activity {
    private TextView value;
    private SeekBar slider;
    private int dim = 45;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        dim = getPreferences(0).getInt("dim", 45);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 48, 28, 24);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("UltraDim");
        title.setTextSize(30);
        title.setTextColor(Color.BLACK);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("Réduis encore la luminosité avec un voile noir réglable, même dans les autres applications.");
        info.setTextSize(16);
        info.setTextColor(Color.DKGRAY);
        info.setPadding(0, 20, 0, 24);
        root.addView(info);

        value = new TextView(this);
        value.setTextSize(20);
        value.setTextColor(Color.BLACK);
        root.addView(value);

        slider = new SeekBar(this);
        slider.setMax(85);
        slider.setProgress(dim);
        root.addView(slider, new LinearLayout.LayoutParams(-1, -2));
        updateLabel();

        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) {
                dim = p;
                getPreferences(0).edit().putInt("dim", dim).apply();
                updateLabel();
                Intent i = new Intent(MainActivity.this, DimOverlayService.class);
                i.setAction(DimOverlayService.ACTION_UPDATE);
                i.putExtra("dim", dim);
                startService(i);
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });

        Button start = new Button(this);
        start.setText("Activer le filtre");
        root.addView(start);
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else {
                Intent i = new Intent(this, DimOverlayService.class);
                i.setAction(DimOverlayService.ACTION_START);
                i.putExtra("dim", dim);
                startForegroundService(i);
            }
        });

        Button stop = new Button(this);
        stop.setText("Désactiver le filtre");
        root.addView(stop);
        stop.setOnClickListener(v -> stopService(new Intent(this, DimOverlayService.class)));

        TextView warning = new TextView(this);
        warning.setText("Important : ce filtre ajoute un voile noir par-dessus l’écran. Il ne modifie pas la luminosité matérielle. Autorise « Afficher par-dessus les autres applis » pour l’utiliser partout. Tu peux revenir ici pour le désactiver.");
        warning.setTextSize(13);
        warning.setTextColor(Color.DKGRAY);
        warning.setPadding(0, 28, 0, 0);
        root.addView(warning);
        setContentView(root);
    }

    private void updateLabel() {
        value.setText("Assombrissement supplémentaire : " + dim + " %");
    }
}
