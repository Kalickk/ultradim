ULTRADIM — projet Android

Fonction : curseur de 0 à 85 % d'assombrissement supplémentaire par superposition noire.
Compatible Android 6.0+ (minSdk 23), conçu pour Android récent.

Installation / compilation :
1. Ouvrir Android Studio.
2. Choisir « Open » et sélectionner le dossier UltraDim décompressé.
3. Laisser Gradle synchroniser le projet.
4. Connecter le téléphone Android et lancer l'application avec Run.

Première utilisation :
1. Appuyer sur « Activer le filtre ».
2. Android ouvre l'écran d'autorisation « Afficher par-dessus les autres applis ».
3. Autoriser UltraDim, revenir dans l'application et appuyer de nouveau sur « Activer le filtre ».
4. Régler le curseur. Le filtre reste actif en quittant l'application.
5. Revenir dans UltraDim et appuyer sur « Désactiver le filtre » pour retirer le voile.

Note : cette application ne change pas la luminosité physique de l'écran ; elle pose un voile noir transparent au-dessus des applications. À forte valeur, certains éléments peuvent devenir difficiles à lire. Le filtre peut ne pas s'appliquer à certaines fenêtres système sécurisées.
