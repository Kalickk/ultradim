package com.example.ultradim;

import android.app.*;
import android.content.*;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.*;
import android.widget.FrameLayout;

public class DimOverlayService extends Service {
    public static final String ACTION_START = "START_DIM";
    public static final String ACTION_UPDATE = "UPDATE_DIM";
    private WindowManager wm;
    private View overlay;
    private WindowManager.LayoutParams params;
    private int dim = 45;
    private static final String CHANNEL = "ultradim_channel";

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            dim = intent.getIntExtra("dim", dim);
            if (ACTION_START.equals(intent.getAction())) {
                Notification n = new Notification.Builder(this, CHANNEL)
                    .setContentTitle("UltraDim actif")
                    .setContentText("Le filtre d’assombrissement est activé.")
                    .setSmallIcon(android.R.drawable.ic_menu_view)
                    .setOngoing(true).build();
                startForeground(1, n);
                showOverlay();
            } else if (ACTION_UPDATE.equals(intent.getAction()) && overlay != null) {
                updateOverlay();
            }
        }
        return START_STICKY;
    }

    private void showOverlay() {
        if (overlay != null) return;
        overlay = new FrameLayout(this);
        overlay.setBackgroundColor(0xFF000000);
        overlay.setAlpha(dim / 100f);
        int type = Build.VERSION.SDK_INT >= 26 ?
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
            WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;
        params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        wm.addView(overlay, params);
    }

    private void updateOverlay() {
        overlay.setAlpha(dim / 100f);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "UltraDim", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    @Override public void onDestroy() {
        if (overlay != null) { wm.removeView(overlay); overlay = null; }
        stopForeground(true);
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i) { return null; }
}
